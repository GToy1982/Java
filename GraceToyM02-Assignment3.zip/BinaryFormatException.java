public class BinaryFormatException extends Exception {
    // Custom exception for binary format errors
    public BinaryFormatException(String message) {
        super(message);
    }

}